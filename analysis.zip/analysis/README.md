# Project analysis

Place the deliverables of your project analysis in this folder.

- Project pitch
- UML class diagram
- Conceptual and logical entity-relationship diagram
- User Stories
